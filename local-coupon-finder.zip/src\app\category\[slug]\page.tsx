import Navbar from '@/components/Navbar';
import CouponCard from '@/components/CouponCard';
import { MOCK_COUPONS } from '@/data/coupons';

export default async function CategoryPage({
    params,
}: {
    params: Promise<{ slug: string }>
}) {
    const { slug } = await params;

    const categoryName = slug.charAt(0).toUpperCase() + slug.slice(1);
    const filteredCoupons = MOCK_COUPONS.filter((coupon) => coupon.category === slug);

    return (
        <main className="min-h-screen">
            <Navbar />

            <div className="bg-slate-900 border-b border-slate-700 py-12">
                <div className="container">
                    <h1 className="text-4xl font-bold mb-4">{categoryName} Deals</h1>
                    <p className="text-gray-400 max-w-2xl">
                        Browse the best discounts for {categoryName.toLowerCase()} in your area.
                    </p>
                </div>
            </div>

            <div className="container py-12">
                {filteredCoupons.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredCoupons.map((coupon) => (
                            <CouponCard key={coupon.id} coupon={coupon} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 bg-slate-800 rounded-xl border border-slate-800">
                        <p className="text-xl text-gray-400">No coupons found in this category yet.</p>
                        <p className="text-gray-500 mt-2">Check back later for new deals!</p>
                    </div>
                )}
            </div>
        </main>
    );
}
