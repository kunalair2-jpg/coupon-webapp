import Navbar from '@/components/Navbar';
import CouponCard from '@/components/CouponCard';
import { MOCK_COUPONS } from '@/data/coupons';

export default async function SearchPage({
    searchParams,
}: {
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
    const params = await searchParams;
    const query = typeof params.q === 'string' ? params.q.toLowerCase() : '';
    const location = typeof params.location === 'string' ? params.location.toLowerCase() : '';

    const filteredCoupons = MOCK_COUPONS.filter((coupon) => {
        const matchesQuery = query
            ? coupon.title.toLowerCase().includes(query) ||
            coupon.businessName.toLowerCase().includes(query) ||
            coupon.description.toLowerCase().includes(query)
            : true;

        const matchesLocation = location
            ? coupon.location.toLowerCase().includes(location)
            : true;

        return matchesQuery && matchesLocation;
    });

    return (
        <main className="min-h-screen">
            <Navbar />

            <div className="bg-slate-900 border-b border-slate-700 py-12">
                <div className="container">
                    <h1 className="text-3xl font-bold mb-6">Find Discounts Near You</h1>

                    <form className="flex gap-4 max-w-2xl bg-slate-800 p-4 border-slate-700 border rounded-xl" style={{ padding: '1rem' }}>
                        <div className="flex-1 relative">
                            <span className="absolute text-gray-400" style={{ left: '0.75rem', top: '0.75rem' }}>🔍</span>
                            <input
                                name="q"
                                defaultValue={query}
                                placeholder="Search for pizza, salon, etc..."
                                className="input"
                                style={{ paddingLeft: '2.5rem' }}
                            />
                        </div>
                        <div className="flex-1 relative">
                            <span className="absolute text-gray-400" style={{ left: '0.75rem', top: '0.75rem' }}>📍</span>
                            <input
                                name="location"
                                defaultValue={location}
                                placeholder="City or Zip Code"
                                className="input"
                                style={{ paddingLeft: '2.5rem' }}
                            />
                        </div>
                        <button type="submit" className="btn btn-primary">
                            Search
                        </button>
                    </form>
                </div>
            </div>

            <div className="container py-12">
                <h2 className="text-2xl font-bold mb-8">
                    {filteredCoupons.length} Results Found
                </h2>

                {filteredCoupons.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {filteredCoupons.map((coupon) => (
                            <CouponCard key={coupon.id} coupon={coupon} />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-20 bg-slate-800 rounded-xl border-slate-800 border" style={{ padding: '5rem 0' }}>
                        <p className="text-xl text-gray-400">No coupons found matching your criteria.</p>
                        <p className="text-gray-500 mt-2">Try searching for "pizza" or "New York".</p>
                    </div>
                )}
            </div>
        </main>
    );
}
