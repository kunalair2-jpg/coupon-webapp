import Link from 'next/link';
import Navbar from '@/components/Navbar';

const categories = [
  { name: 'Salons', icon: '💇‍♀️', slug: 'salons' },
  { name: 'Parlors', icon: '💅', slug: 'parlors' },
  { name: 'Cafes', icon: '☕', slug: 'cafes' },
  { name: 'Restaurants', icon: '🍽️', slug: 'restaurants' },
  { name: 'Bars', icon: '🍻', slug: 'bars' },
  { name: 'Shopping', icon: '🛍️', slug: 'shopping' },
];

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 hero-bg-gradient z-10" />
        <div className="container text-center relative">
          <h1 className="text-5xl font-extrabold mb-6 animate-fade-in">
            Discover Local <span className="text-gradient">Discounts</span>
          </h1>
          <p className="text-xl text-gray-400 mb-10 text-center animate-fade-in" style={{ animationDelay: '0.1s', margin: '0 auto 2.5rem auto', maxWidth: '42rem' }}>
            Find the best deals in your city. From salons to restaurants, save money on everything you love.
          </p>

          <div className="animate-fade-in" style={{ animationDelay: '0.2s', maxWidth: '28rem', margin: '0 auto' }}>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Enter your city or zip code..."
                className="input"
                style={{ flex: 1 }}
              />
              <button className="btn btn-primary">
                Search
              </button>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">Try "New York" or "Los Angeles"</p>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 container">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold">Browse Categories</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
          {categories.map((cat) => (
            <Link href={`/category/${cat.slug}`} key={cat.slug} className="h-full">
              <div className="card h-full flex flex-col items-center justify-center text-center">
                <span className="text-4xl mb-4" style={{ display: 'block' }}>
                  {cat.icon}
                </span>
                <h3 className="text-xl font-bold mb-2">{cat.name}</h3>
                <p className="text-sm text-gray-400">Find deals in {cat.name}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Deals Placeholder */}
      <section className="py-16 bg-slate-900">
        <div className="container">
          <h2 className="text-3xl font-bold mb-8">Trending Deals Nearby</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card flex gap-4">
              <div style={{ fontSize: '3rem', background: '#e11d48', width: '6rem', height: '6rem', borderRadius: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>🍕</div>
              <div>
                <span className="text-xs uppercase font-bold text-gray-500 mb-2" style={{ display: 'block' }}>Restaurant</span>
                <h3 className="text-xl font-bold">50% Off Pizza at Joe's</h3>
                <p className="text-gray-400 text-sm mb-4">Valid until Friday. 2 miles away.</p>
                <button className="btn btn-primary text-sm">Redeem Now</button>
              </div>
            </div>
            <div className="card flex gap-4">
              <div style={{ fontSize: '3rem', background: '#9333ea', width: '6rem', height: '6rem', borderRadius: '0.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>💇‍♀️</div>
              <div>
                <span className="text-xs uppercase font-bold text-gray-500 mb-2" style={{ display: 'block' }}>Salon</span>
                <h3 className="text-xl font-bold">Free Haircut with Color</h3>
                <p className="text-gray-400 text-sm mb-4">New customers only. 0.5 miles away.</p>
                <button className="btn btn-primary text-sm">Redeem Now</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="py-12 border-t border-slate-700 text-center text-gray-500 text-sm mt-10">
        &copy; {new Date().getFullYear()} Local Coupon Finder. All rights reserved.
      </footer>
    </main>
  );
}
