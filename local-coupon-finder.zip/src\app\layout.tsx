import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Local Coupon Finder | Best Discounts Near You",
  description: "Find the best deals in your city for salons, restaurants, and more.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="layout-wrapper">
          {/* Navbar could go here globally if we wanted */}
          {children}
        </div>
      </body>
    </html>
  );
}
