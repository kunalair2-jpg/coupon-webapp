"use client";
import React, { useState } from 'react';
import { Coupon } from '@/data/coupons';

export default function CouponCard({ coupon }: { coupon: Coupon }) {
    const [showCode, setShowCode] = React.useState(false);

    return (
        <div className="card flex flex-col h-full bg-slate-800 border-slate-700">
            <div className="flex justify-between mb-4">
                <div>
                    <span className="text-xs uppercase font-bold text-gray-400">
                        {coupon.category} • {coupon.distance}
                    </span>
                    <h3 className="text-xl font-bold mt-2">{coupon.businessName}</h3>
                </div>
                <div style={{ background: 'rgba(99, 102, 241, 0.2)', color: 'var(--primary)', padding: '0.25rem 0.75rem', borderRadius: '0.25rem', fontSize: '0.875rem', fontWeight: 'bold', whiteSpace: 'nowrap' }}>
                    {coupon.discount}
                </div>
            </div>

            <p className="text-gray-400 text-sm mb-4" style={{ flexGrow: 1 }}>{coupon.description}</p>

            <div className="border-slate-700 pt-4" style={{ borderTopWidth: '1px', marginTop: 'auto' }}>
                <div className="flex justify-between items-center text-sm text-gray-400 mb-4">
                    <span>📍 {coupon.location}</span>
                    <span>📅 {coupon.expiry}</span>
                </div>

                <button
                    onClick={() => setShowCode(!showCode)}
                    className="w-full font-bold"
                    style={{
                        padding: '0.5rem 0',
                        borderRadius: '0.25rem',
                        background: showCode ? '#334155' : 'var(--primary)',
                        color: 'white',
                        cursor: showCode ? 'text' : 'pointer',
                        border: 'none',
                        fontSize: '1rem'
                    }}
                >
                    {showCode ? (
                        <span className="flex items-center justify-center gap-2">
                            Code: <span style={{ fontFamily: 'monospace', fontSize: '1.25rem' }}>{coupon.code}</span>
                        </span>
                    ) : (
                        'Redeem Coupon'
                    )}
                </button>
            </div>
        </div>
    );
}
