import Link from 'next/link';
import React from 'react';

export default function Navbar() {
    return (
        <nav style={{
            padding: '1rem 0',
            borderBottom: '1px solid var(--card-border)',
            background: 'rgba(255, 255, 255, 0.8)',
            backdropFilter: 'blur(10px)',
            position: 'sticky',
            top: 0,
            zIndex: 100
        }}>
            <div className="container" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Link href="/" style={{ fontSize: '1.5rem', fontWeight: 'bold', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    <span style={{ color: 'var(--primary)' }}>Coupon</span>Finder
                </Link>
                <div style={{ display: 'flex', gap: '1rem' }}>
                    <Link href="/search" className="btn btn-secondary" style={{ fontSize: '0.9rem', padding: '0.5rem 1rem' }}>
                        Find Deals
                    </Link>
                    <Link href="/admin" className="btn btn-primary" style={{ fontSize: '0.9rem', padding: '0.5rem 1rem' }}>
                        Partner Login
                    </Link>
                </div>
            </div>
        </nav>
    );
}
