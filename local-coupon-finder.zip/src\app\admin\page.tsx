"use client";
import React, { useState } from 'react';
import Navbar from '@/components/Navbar';

export default function AdminPage() {
    const [isLogin, setIsLogin] = useState(true);
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const handleAuth = (e: React.FormEvent) => {
        e.preventDefault();
        // Mock authentication
        setIsLoggedIn(true);
    };

    if (isLoggedIn) {
        return (
            <main className="min-h-screen">
                <Navbar />
                <div className="container py-12">
                    <h1 className="text-3xl font-bold mb-8">Partner Dashboard</h1>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div className="card">
                            <h3 className="text-gray-400 text-sm font-bold uppercase mb-2">Active Coupons</h3>
                            <p className="text-4xl font-bold">3</p>
                        </div>
                        <div className="card">
                            <h3 className="text-gray-400 text-sm font-bold uppercase mb-2">Total Redemptions</h3>
                            <p className="text-4xl font-bold">128</p>
                        </div>
                        <div className="card">
                            <h3 className="text-gray-400 text-sm font-bold uppercase mb-2">Views</h3>
                            <p className="text-4xl font-bold">1,024</p>
                        </div>
                    </div>

                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold">Your Coupons</h2>
                        <button className="btn btn-primary">+ Create New Coupon</button>
                    </div>

                    <div className="bg-slate-800 rounded-lg overflow-hidden border border-slate-700">
                        <table className="w-full text-left">
                            <thead className="bg-slate-900 border-b border-slate-700">
                                <tr>
                                    <th style={{ padding: '1rem' }}>Coupon Title</th>
                                    <th style={{ padding: '1rem' }}>Discount</th>
                                    <th style={{ padding: '1rem' }}>Status</th>
                                    <th style={{ padding: '1rem' }}>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="border-b border-slate-700">
                                    <td style={{ padding: '1rem' }}>50% Off Pizza</td>
                                    <td style={{ padding: '1rem' }}>50%</td>
                                    <td className="text-green-400" style={{ padding: '1rem' }}>Active</td>
                                    <td style={{ padding: '1rem' }}><button className="text-sm text-primary" style={{ textDecoration: 'underline', cursor: 'pointer' }}>Edit</button></td>
                                </tr>
                                <tr className="border-b border-slate-700">
                                    <td style={{ padding: '1rem' }}>Free Drink with Meal</td>
                                    <td style={{ padding: '1rem' }}>Free Item</td>
                                    <td className="text-green-400" style={{ padding: '1rem' }}>Active</td>
                                    <td style={{ padding: '1rem' }}><button className="text-sm text-primary" style={{ textDecoration: 'underline', cursor: 'pointer' }}>Edit</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        );
    }

    return (
        <main className="min-h-screen">
            <Navbar />
            <div className="container flex items-center justify-center h-full" style={{ minHeight: '80vh' }}>
                <div className="max-w-md w-full card shadow-2xl" style={{ padding: '2rem' }}>
                    <h1 className="text-3xl font-bold text-center mb-2">
                        {isLogin ? 'Partner Login' : 'Register Business'}
                    </h1>
                    <p className="text-center text-gray-400 mb-8">
                        Manage your coupons and track redemptions.
                    </p>

                    <form onSubmit={handleAuth} className="flex flex-col gap-4">
                        {!isLogin && (
                            <>
                                <div>
                                    <label className="block text-sm font-bold mb-2">Business Name</label>
                                    <input type="text" className="input" placeholder="Joe's Pizza" required />
                                </div>
                                <div>
                                    <label className="block text-sm font-bold mb-2">Category</label>
                                    <select className="input" style={{ cursor: 'pointer' }}>
                                        <option value="restaurants">Restaurant</option>
                                        <option value="salons">Salon</option>
                                        <option value="cafes">Cafe</option>
                                        <option value="bars">Bar</option>
                                        <option value="shopping">Shopping</option>
                                        <option value="parlors">Parlor</option>
                                    </select>
                                </div>
                            </>
                        )}

                        <div>
                            <label className="block text-sm font-bold mb-2">Email</label>
                            <input type="email" className="input" placeholder="owner@business.com" required />
                        </div>

                        <div>
                            <label className="block text-sm font-bold mb-2">Password</label>
                            <input type="password" className="input" placeholder="••••••••" required />
                        </div>

                        <button type="submit" className="btn btn-primary w-full mt-2">
                            {isLogin ? 'Login' : 'Create Account'}
                        </button>
                    </form>

                    <div className="text-center mt-6">
                        <button
                            onClick={() => setIsLogin(!isLogin)}
                            className="text-primary text-sm"
                            style={{ textDecoration: 'underline', background: 'none', border: 'none', cursor: 'pointer' }}
                        >
                            {isLogin ? "Don't have an account? Register" : "Already have an account? Login"}
                        </button>
                    </div>
                </div>
            </div>
        </main>
    );
}
