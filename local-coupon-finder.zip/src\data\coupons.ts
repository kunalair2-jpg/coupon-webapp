export interface Coupon {
    id: string;
    title: string;
    businessName: string;
    category: 'salons' | 'parlors' | 'cafes' | 'restaurants' | 'bars' | 'shopping';
    discount: string;
    description: string;
    location: string;
    distance: string;
    expiry: string;
    code: string;
}

export const MOCK_COUPONS: Coupon[] = [
    {
        id: '1',
        title: '50% Off Any Large Pizza',
        businessName: "Joe's Pizza",
        category: 'restaurants',
        discount: '50% OFF',
        description: 'Get half off any large deep dish or thin crust pizza.',
        location: 'New York, NY',
        distance: '0.5 miles',
        expiry: 'Valid until Sat',
        code: 'PIZZA50'
    },
    {
        id: '2',
        title: 'Free Hair Treatment',
        businessName: "Luxe Salon",
        category: 'salons',
        discount: 'FREE',
        description: 'Free deep conditioning treatment with any haircut.',
        location: 'Brooklyn, NY',
        distance: '2 miles',
        expiry: 'Valid until Sun',
        code: 'LUXEHAIR'
    },
    {
        id: '3',
        title: 'Buy 1 Get 1 Free Latte',
        businessName: "Bean & Brew",
        category: 'cafes',
        discount: 'BOGO',
        description: 'Buy any latte and get one of equal or lesser value for free.',
        location: 'Queens, NY',
        distance: '1.2 miles',
        expiry: 'Valid today only',
        code: 'BOGOLATTE'
    },
    {
        id: '4',
        title: '20% Off All Manicures',
        businessName: "Polished Nail Bar",
        category: 'parlors',
        discount: '20% OFF',
        description: 'Weekday special: 20% off all manicures and pedicures.',
        location: 'New York, NY',
        distance: '0.8 miles',
        expiry: 'Valid Mon-Thu',
        code: 'NAIL20'
    },
    {
        id: '5',
        title: 'Happy Hour All Night',
        businessName: "Skyline Bar",
        category: 'bars',
        discount: 'Happy Hour',
        description: '$5 beers and $8 cocktails all night long.',
        location: 'Manhattan, NY',
        distance: '1.5 miles',
        expiry: 'Valid Fri-Sat',
        code: 'SKYHIGH'
    },
    {
        id: '6',
        title: '15% Off Summer Collection',
        businessName: "Trendy Threads",
        category: 'shopping',
        discount: '15% OFF',
        description: 'Get 15% off anything from the new summer collection.',
        location: 'SoHo, NY',
        distance: '3 miles',
        expiry: 'Valid this week',
        code: 'SUMMER15'
    }
];
